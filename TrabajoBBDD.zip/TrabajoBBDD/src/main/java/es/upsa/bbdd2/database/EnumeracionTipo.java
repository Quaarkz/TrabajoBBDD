package es.upsa.bbdd2.database;

public enum EnumeracionTipo {

    ENTRANTE, PRINCIPAL, POSTRE, INFANTIL
}
