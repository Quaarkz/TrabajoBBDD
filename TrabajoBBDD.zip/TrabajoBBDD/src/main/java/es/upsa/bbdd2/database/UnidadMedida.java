package es.upsa.bbdd2.database;

public enum UnidadMedida {

    GRAMOS, UNIDADES, CENTILITROS
}
